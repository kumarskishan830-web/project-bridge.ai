/*
# BridgeAI — Create conversations and messages tables

## Overview
This migration creates the database schema for BridgeAI, an app that analyzes
user-described problems and generates AI action reports. Since this is a
single-tenant app with no sign-in, all policies allow anon + authenticated access.

## New Tables

### conversations
- `id` (uuid, primary key)
- `title` (text, not null) — short title/summary of the conversation
- `created_at` (timestamptz, default now)

### messages
- `id` (uuid, primary key)
- `conversation_id` (uuid, foreign key to conversations, on delete cascade)
- `role` (text, not null) — 'user' or 'assistant'
- `content` (text, not null) — the message text
- `analysis` (jsonb, nullable) — structured AI analysis (priority, tags, summary, affected people, actions, safety warning)
- `created_at` (timestamptz, default now)

## Security
- RLS enabled on both tables.
- All policies use `TO anon, authenticated` with `USING (true)` because this is
  a single-tenant app with intentionally shared/public data (no sign-in).

## Notes
1. Index on messages.conversation_id for efficient lookups.
2. Conversations ordered by created_at desc in the UI.
*/

CREATE TABLE IF NOT EXISTS conversations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE conversations ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_conversations" ON conversations;
CREATE POLICY "anon_select_conversations" ON conversations FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_conversations" ON conversations;
CREATE POLICY "anon_insert_conversations" ON conversations FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_conversations" ON conversations;
CREATE POLICY "anon_update_conversations" ON conversations FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_conversations" ON conversations;
CREATE POLICY "anon_delete_conversations" ON conversations FOR DELETE
  TO anon, authenticated USING (true);

CREATE TABLE IF NOT EXISTS messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  conversation_id uuid NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
  role text NOT NULL CHECK (role IN ('user', 'assistant')),
  content text NOT NULL,
  analysis jsonb,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE messages ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_messages" ON messages;
CREATE POLICY "anon_select_messages" ON messages FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_messages" ON messages;
CREATE POLICY "anon_insert_messages" ON messages FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_messages" ON messages;
CREATE POLICY "anon_update_messages" ON messages FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_messages" ON messages;
CREATE POLICY "anon_delete_messages" ON messages FOR DELETE
  TO anon, authenticated USING (true);

CREATE INDEX IF NOT EXISTS idx_messages_conversation_id ON messages(conversation_id);
