import { createClient } from "npm:@supabase/supabase-js@2.57.4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface AnalysisRequest {
  problem: string;
}

interface AnalysisResult {
  priority: string;
  priorityLevel: "high" | "medium" | "low";
  tags: string[];
  summary: string;
  affectedPeople: string;
  actions: string[];
  safetyWarning: string;
}

const PRIORITY_KEYWORDS: Record<string, "high" | "medium" | "low"> = {
  flood: "high",
  fire: "high",
  earthquake: "high",
  accident: "high",
  emergency: "high",
  danger: "high",
  injured: "high",
  crash: "high",
  storm: "high",
  rain: "medium",
  traffic: "medium",
  road: "medium",
  broken: "medium",
  leak: "medium",
  noise: "low",
  litter: "low",
  parking: "low",
  "street light": "low",
};

const TAG_KEYWORDS: Record<string, string> = {
  "flood": "Weather",
  "rain": "Weather",
  "storm": "Weather",
  "fire": "Fire Safety",
  "earthquake": "Natural Disaster",
  "traffic": "Traffic",
  "road": "Traffic",
  "cars": "Traffic",
  "accident": "Emergency",
  "injured": "Medical",
  "medical": "Medical",
  "hospital": "Medical",
  "electricity": "Utility",
  "power": "Utility",
  "water": "Utility",
  "leak": "Infrastructure",
  "broken": "Infrastructure",
  "noise": "Community",
  "litter": "Community",
  "parking": "Community",
  "street light": "Infrastructure",
  "pollution": "Environment",
  "tree": "Environment",
  "animal": "Wildlife",
  "crime": "Safety",
  "theft": "Safety",
  "security": "Safety",
};

function analyzeProblem(problem: string): AnalysisResult {
  const lower = problem.toLowerCase();

  let priorityLevel: "high" | "medium" | "low" = "low";
  for (const [keyword, level] of Object.entries(PRIORITY_KEYWORDS)) {
    if (lower.includes(keyword)) {
      if (level === "high") {
        priorityLevel = "high";
        break;
      }
      if (level === "medium" && priorityLevel !== "high") {
        priorityLevel = "medium";
      }
    }
  }

  const tags: string[] = [];
  const seenTags = new Set<string>();
  for (const [keyword, tag] of Object.entries(TAG_KEYWORDS)) {
    if (lower.includes(keyword) && !seenTags.has(tag)) {
      tags.push(tag);
      seenTags.add(tag);
    }
  }
  if (tags.length === 0) tags.push("General");

  const priorityLabel =
    priorityLevel === "high"
      ? "HIGH PRIORITY"
      : priorityLevel === "medium"
        ? "MEDIUM PRIORITY"
        : "LOW PRIORITY";

  const sentences = problem.split(/[.!?]+/).filter((s) => s.trim().length > 0);
  const summary =
    sentences.length > 0
      ? sentences[0].trim().charAt(0).toUpperCase() +
        sentences[0].trim().slice(1) +
        (sentences.length > 1 ? " The situation requires attention and appropriate action." : ".")
      : "A situation has been reported that requires attention.";

  const affectedPeopleMap: Record<string, string> = {
    high: "People in the immediate vicinity, bystanders, and potentially emergency responders. The situation may escalate quickly if not addressed.",
    medium: "Nearby residents, commuters, and people passing through the area. The impact is localized but disruptive.",
    low: "People in the surrounding area. The issue is minor but affects quality of life for the community.",
  };

  const actionsMap: Record<string, string[]> = {
    high: [
      "Ensure immediate safety — move away from the hazard area if possible.",
      "Contact emergency services (pollice, fire department, or medical) if lives are at risk.",
      "Alert people nearby about the danger and help them move to safety.",
      "Document the situation with photos or notes for authorities.",
      "Follow instructions from emergency responders when they arrive.",
    ],
    medium: [
      "Assess the situation and identify the scope of the problem.",
      "Report the issue to the relevant local authority or service department.",
      "Use an alternate route or workaround if available.",
      "Inform nearby people who may be affected.",
      "Monitor the situation and follow up if it worsens.",
    ],
    low: [
      "Note the details of the issue for your records.",
      "Report the problem to the appropriate local service or community board.",
      "If possible, take a small corrective action yourself (e.g., picking up litter).",
      "Check back on the situation in a few days to see if it was resolved.",
    ],
  };

  const safetyMap: Record<string, string> = {
    high: "This is a potentially dangerous situation. Do not attempt to handle it alone. Keep a safe distance, do not put yourself or others at risk, and wait for professional help to arrive.",
    medium: "Exercise caution while dealing with this issue. Avoid taking risks and use common sense. If the situation worsens or becomes dangerous, escalate to emergency services immediately.",
    low: "This situation does not pose an immediate safety threat, but remain aware of your surroundings. If conditions change, reassess and take appropriate action.",
  };

  return {
    priority: priorityLabel,
    priorityLevel,
    tags,
    summary,
    affectedPeople: affectedPeopleMap[priorityLevel],
    actions: actionsMap[priorityLevel],
    safetyWarning: safetyMap[priorityLevel],
  };
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    if (req.method !== "POST") {
      return new Response(
        JSON.stringify({ error: "Method not allowed" }),
        { status: 405, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    const body = await req.json() as AnalysisRequest;
    const { problem } = body;

    if (!problem || typeof problem !== "string" || problem.trim().length === 0) {
      return new Response(
        JSON.stringify({ error: "Problem description is required" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    const analysis = analyzeProblem(problem);

    return new Response(
      JSON.stringify(analysis),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  } catch (err) {
    return new Response(
      JSON.stringify({ error: "Failed to analyze problem" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  }
});
