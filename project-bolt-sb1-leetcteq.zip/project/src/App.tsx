import { useState, useEffect, useRef, useCallback } from 'react';
import { Menu, Globe, Presentation as PresentationIcon } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { Conversation, Message, Analysis } from '@/types';
import Sidebar from '@/components/Sidebar';
import ChatMessage from '@/components/ChatMessage';
import ChatInput from '@/components/ChatInput';
import TypingIndicator from '@/components/TypingIndicator';
import WelcomeScreen from '@/components/WelcomeScreen';
import Presentation from '@/components/Presentation';

export default function App() {
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [activeId, setActiveId] = useState<string | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [showPresentation, setShowPresentation] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const loadConversations = useCallback(async () => {
    const { data, error } = await supabase
      .from('conversations')
      .select('*')
      .order('created_at', { ascending: false });
    if (error) {
      console.error('Failed to load conversations:', error.message);
      return;
    }
    setConversations(data || []);
  }, []);

  const loadMessages = useCallback(async (convId: string) => {
    const { data, error } = await supabase
      .from('messages')
      .select('*')
      .eq('conversation_id', convId)
      .order('created_at', { ascending: true });
    if (error) {
      console.error('Failed to load messages:', error.message);
      return;
    }
    setMessages(data || []);
  }, []);

  useEffect(() => {
    loadConversations();
  }, [loadConversations]);

  useEffect(() => {
    if (activeId) {
      loadMessages(activeId);
    } else {
      setMessages([]);
    }
  }, [activeId, loadMessages]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading]);

  const handleNew = () => {
    setActiveId(null);
    setMessages([]);
    setSidebarOpen(false);
  };

  const handleSelect = (id: string) => {
    setActiveId(id);
    setSidebarOpen(false);
  };

  const handleDelete = async (id: string) => {
    const { error } = await supabase.from('conversations').delete().eq('id', id);
    if (error) {
      console.error('Failed to delete conversation:', error.message);
      return;
    }
    setConversations((prev) => prev.filter((c) => c.id !== id));
    if (activeId === id) {
      setActiveId(null);
      setMessages([]);
    }
  };

  const callAnalysis = async (problem: string): Promise<Analysis> => {
    const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/analyze-problem`;
    const response = await fetch(apiUrl, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ problem }),
    });
    if (!response.ok) {
      throw new Error(`Analysis failed (${response.status})`);
    }
    const data = await response.json();
    if (data.error) {
      throw new Error(data.error);
    }
    return data as Analysis;
  };

  const handleSubmit = async () => {
    const text = input.trim();
    if (!text || isLoading) return;

    setInput('');
    setIsLoading(true);

    let convId = activeId;
    let convTitle = text.slice(0, 50) + (text.length > 50 ? '...' : '');

    try {
      if (!convId) {
        const { data: conv, error: convError } = await supabase
          .from('conversations')
          .insert({ title: convTitle })
          .select()
          .single();
        if (convError || !conv) {
          throw new Error(convError?.message || 'Failed to create conversation');
        }
        convId = conv.id;
        setActiveId(convId);
        setConversations((prev) => [conv as Conversation, ...prev]);
      }

      const { data: userMsg, error: msgError } = await supabase
        .from('messages')
        .insert({
          conversation_id: convId,
          role: 'user',
          content: text,
        })
        .select()
        .single();

      if (msgError || !userMsg) {
        throw new Error(msgError?.message || 'Failed to save message');
      }
      setMessages((prev) => [...prev, userMsg as Message]);

      const analysis = await callAnalysis(text);

      const assistantContent = `Here's my analysis of the situation you described:`;
      const { data: aiMsg, error: aiError } = await supabase
        .from('messages')
        .insert({
          conversation_id: convId,
          role: 'assistant',
          content: assistantContent,
          analysis: analysis,
        })
        .select()
        .single();

      if (aiError || !aiMsg) {
        throw new Error(aiError?.message || 'Failed to save analysis');
      }
      setMessages((prev) => [...prev, aiMsg as Message]);
    } catch (err) {
      console.error('Analysis error:', err);
      const errorMsg = err instanceof Error ? err.message : 'Something went wrong';
      const { data: errMsg } = await supabase
        .from('messages')
        .insert({
          conversation_id: convId,
          role: 'assistant',
          content: `Sorry, I couldn't analyze your problem. ${errorMsg}. Please try again.`,
          analysis: null,
        })
        .select()
        .single();
      if (errMsg) {
        setMessages((prev) => [...prev, errMsg as Message]);
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleExample = (text: string) => {
    setInput(text);
  };

  return (
    <div className="flex h-screen bg-[#0b0b12] text-white overflow-hidden">
      <Sidebar
        conversations={conversations}
        activeId={activeId}
        onSelect={handleSelect}
        onNew={handleNew}
        onDelete={handleDelete}
        isOpen={sidebarOpen}
        onClose={() => setSidebarOpen(false)}
      />

      <main className="flex-1 flex flex-col min-w-0">
        <header className="flex items-center gap-3 px-4 py-3 border-b border-white/5 bg-[#0b0b12]/80 backdrop-blur-sm">
          <button
            onClick={() => setSidebarOpen(true)}
            className="md:hidden p-2 rounded-lg hover:bg-white/5 transition-colors"
          >
            <Menu className="w-5 h-5" />
          </button>
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-pink-500 to-pink-600 flex items-center justify-center">
              <Globe className="w-5 h-5 text-white" />
            </div>
            <span className="font-semibold text-white">BridgeAI</span>
          </div>
          <button
            onClick={() => setShowPresentation(true)}
            className="ml-auto flex items-center gap-2 px-3 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 transition-colors text-sm text-gray-300"
          >
            <PresentationIcon className="w-4 h-4" />
            <span className="hidden sm:inline">Presentation</span>
          </button>
          {activeId && (
            <span className="text-gray-500 text-sm hidden sm:inline">
              {conversations.find((c) => c.id === activeId)?.title}
            </span>
          )}
        </header>

        <div className="flex-1 overflow-y-auto scrollbar-thin">
          {messages.length === 0 && !isLoading ? (
            <WelcomeScreen onExample={handleExample} />
          ) : (
            <div className="max-w-3xl mx-auto px-4 py-6 space-y-6">
              {messages.map((msg) => (
                <ChatMessage key={msg.id} message={msg} />
              ))}
              {isLoading && <TypingIndicator />}
              <div ref={messagesEndRef} />
            </div>
          )}
        </div>

        <ChatInput
          value={input}
          onChange={setInput}
          onSubmit={handleSubmit}
          isLoading={isLoading}
        />
      </main>

      {showPresentation && (
        <Presentation onClose={() => setShowPresentation(false)} />
      )}
    </div>
  );
}
