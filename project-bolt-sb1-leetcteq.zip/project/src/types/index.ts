export interface Analysis {
  priority: string;
  priorityLevel: 'high' | 'medium' | 'low';
  tags: string[];
  summary: string;
  affectedPeople: string;
  actions: string[];
  safetyWarning: string;
}

export interface Conversation {
  id: string;
  title: string;
  created_at: string;
}

export interface Message {
  id: string;
  conversation_id: string;
  role: 'user' | 'assistant';
  content: string;
  analysis: Analysis | null;
  created_at: string;
}
