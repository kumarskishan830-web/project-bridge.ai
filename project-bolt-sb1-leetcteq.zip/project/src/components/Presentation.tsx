import { useState, useEffect, useCallback } from 'react';
import {
  ChevronLeft,
  ChevronRight,
  Globe,
  AlertTriangle,
  Users,
  CheckCircle2,
  ShieldAlert,
  Sparkles,
  CloudRain,
  Car,
  Zap,
  Database,
  Cloud,
  Code2,
  ArrowRight,
  X,
} from 'lucide-react';

interface Slide {
  id: number;
  title: string;
  render: () => JSX.Element;
}

const slides: Slide[] = [
  {
    id: 0,
    title: 'BridgeAI',
    render: () => (
      <div className="flex flex-col items-center justify-center h-full text-center px-8">
        <div className="w-24 h-24 rounded-3xl bg-gradient-to-br from-pink-500 to-pink-600 flex items-center justify-center mb-8 shadow-2xl shadow-pink-500/30 animate-[float_3s_ease-in-out_infinite]">
          <Globe className="w-12 h-12 text-white" />
        </div>
        <h1 className="text-6xl font-bold text-white mb-4 tracking-tight">
          Bridge<span className="text-pink-400">AI</span>
        </h1>
        <p className="text-2xl text-gray-400 max-w-2xl leading-relaxed">
          Turning human problems into clear and useful actions with Gemini AI
        </p>
        <div className="mt-12 flex items-center gap-2 text-gray-600 text-sm">
          <Sparkles className="w-4 h-4 text-pink-400" />
          <span>An AI-powered problem analysis platform</span>
        </div>
      </div>
    ),
  },
  {
    id: 1,
    title: 'The Problem',
    render: () => (
      <div className="flex flex-col justify-center h-full px-12 max-w-4xl mx-auto">
        <h2 className="text-5xl font-bold text-white mb-3">The Problem</h2>
        <div className="w-20 h-1 bg-pink-500 rounded-full mb-8" />
        <p className="text-2xl text-gray-300 leading-relaxed mb-10">
          When emergencies and community issues happen, people often don't know
          what to do or who to contact.
        </p>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {[
            { icon: AlertTriangle, title: 'Confusion', desc: 'Unclear priority — is this urgent or minor?' },
            { icon: Users, title: 'Uncertainty', desc: 'Who is affected and how badly?' },
            { icon: ShieldAlert, title: 'Inaction', desc: 'No clear steps to take next' },
          ].map((item, i) => {
            const Icon = item.icon;
            return (
              <div
                key={i}
                className="p-6 rounded-2xl bg-[#1a1a24] border border-white/5 hover:border-pink-500/20 transition-colors"
              >
                <div className="w-12 h-12 rounded-xl bg-pink-500/10 flex items-center justify-center mb-4">
                  <Icon className="w-6 h-6 text-pink-400" />
                </div>
                <h3 className="text-white font-semibold text-lg mb-2">{item.title}</h3>
                <p className="text-gray-400 text-sm leading-relaxed">{item.desc}</p>
              </div>
            );
          })}
        </div>
      </div>
    ),
  },
  {
    id: 2,
    title: 'The Solution',
    render: () => (
      <div className="flex flex-col justify-center h-full px-12 max-w-4xl mx-auto">
        <h2 className="text-5xl font-bold text-white mb-3">The Solution</h2>
        <div className="w-20 h-1 bg-pink-500 rounded-full mb-8" />
        <p className="text-2xl text-gray-300 leading-relaxed mb-10">
          BridgeAI analyzes any problem you describe and instantly generates a
          structured action report.
        </p>
        <div className="space-y-3">
          {[
            'Describe your problem in plain language',
            'AI assesses priority, tags, and affected people',
            'Get a numbered list of recommended actions',
            'Receive a safety warning tailored to the situation',
          ].map((step, i) => (
            <div
              key={i}
              className="flex items-center gap-4 p-4 rounded-xl bg-[#1a1a24] border border-white/5"
            >
              <div className="w-8 h-8 rounded-full bg-gradient-to-br from-pink-500 to-pink-600 flex items-center justify-center text-white font-bold text-sm">
                {i + 1}
              </div>
              <span className="text-gray-200 text-lg">{step}</span>
            </div>
          ))}
        </div>
      </div>
    ),
  },
  {
    id: 3,
    title: 'Key Features',
    render: () => (
      <div className="flex flex-col justify-center h-full px-12 max-w-5xl mx-auto">
        <h2 className="text-5xl font-bold text-white mb-3">Key Features</h2>
        <div className="w-20 h-1 bg-pink-500 rounded-full mb-8" />
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {[
            { icon: AlertTriangle, title: 'Priority Assessment', desc: 'Automatic high, medium, or low priority classification' },
            { icon: Sparkles, title: 'Smart Tagging', desc: 'Context-aware category tags like Weather, Traffic, Medical' },
            { icon: Users, title: 'Impact Analysis', desc: 'Identifies who is affected and how severely' },
            { icon: CheckCircle2, title: 'Action Plan', desc: 'Numbered, actionable steps tailored to the situation' },
            { icon: ShieldAlert, title: 'Safety Warnings', desc: 'Contextual safety guidance to prevent harm' },
            { icon: Database, title: 'Saved History', desc: 'All analyses persist — revisit any past conversation' },
          ].map((feature, i) => {
            const Icon = feature.icon;
            return (
              <div
                key={i}
                className="flex items-start gap-4 p-5 rounded-2xl bg-[#1a1a24] border border-white/5 hover:border-pink-500/20 transition-colors"
              >
                <div className="flex-shrink-0 w-11 h-11 rounded-xl bg-pink-500/10 flex items-center justify-center">
                  <Icon className="w-5 h-5 text-pink-400" />
                </div>
                <div>
                  <h3 className="text-white font-semibold text-base mb-1">{feature.title}</h3>
                  <p className="text-gray-400 text-sm leading-relaxed">{feature.desc}</p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    ),
  },
  {
    id: 4,
    title: 'How It Works',
    render: () => (
      <div className="flex flex-col justify-center h-full px-12 max-w-4xl mx-auto">
        <h2 className="text-5xl font-bold text-white mb-3">How It Works</h2>
        <div className="w-20 h-1 bg-pink-500 rounded-full mb-10" />
        <div className="space-y-6">
          {[
            { icon: CloudRain, title: '1. User Describes Problem', desc: '"Heavy rain has flooded the main road and cars are getting stuck..."' },
            { icon: Sparkles, title: '2. AI Analyzes', desc: 'The edge function processes keywords, assesses priority, and generates tags' },
            { icon: CheckCircle2, title: '3. Structured Report', desc: 'Priority badge, tags, summary, affected people, actions, and safety warning' },
          ].map((step, i) => {
            const Icon = step.icon;
            return (
              <div key={i} className="flex items-center gap-5">
                <div className="flex-shrink-0 w-14 h-14 rounded-2xl bg-gradient-to-br from-pink-500/20 to-pink-600/20 border border-pink-500/20 flex items-center justify-center">
                  <Icon className="w-7 h-7 text-pink-400" />
                </div>
                <div className="flex-1">
                  <h3 className="text-white font-semibold text-lg">{step.title}</h3>
                  <p className="text-gray-400 text-sm mt-1">{step.desc}</p>
                </div>
                {i < 2 && <ArrowRight className="w-6 h-6 text-gray-600 rotate-90 md:rotate-0" />}
              </div>
            );
          })}
        </div>
      </div>
    ),
  },
  {
    id: 5,
    title: 'Example Analysis',
    render: () => (
      <div className="flex flex-col justify-center h-full px-12 max-w-3xl mx-auto">
        <h2 className="text-5xl font-bold text-white mb-3">Example Analysis</h2>
        <div className="w-20 h-1 bg-pink-500 rounded-full mb-8" />
        <div className="rounded-2xl bg-[#1a1a24] border border-white/5 p-6 space-y-5">
          <div className="flex items-start gap-3">
            <div className="flex-shrink-0 w-9 h-9 rounded-full bg-gradient-to-br from-pink-500 to-pink-600 flex items-center justify-center">
              <span className="text-white text-xs font-bold">U</span>
            </div>
            <div className="flex-1 rounded-2xl bg-gradient-to-br from-pink-500 to-pink-600 px-5 py-3">
              <p className="text-white text-sm leading-relaxed">
                Heavy rain has flooded the main road and cars are getting stuck. The water is rising fast.
              </p>
            </div>
          </div>
          <div className="flex items-start gap-3">
            <div className="flex-shrink-0 w-9 h-9 rounded-full bg-gradient-to-br from-violet-500 to-purple-600 flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <div className="flex-1 rounded-2xl bg-[#1e1e2e] border border-white/5 px-5 py-4 space-y-4">
              <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-red-500/10 border border-red-500/30">
                <AlertTriangle className="w-4 h-4 text-red-400" />
                <span className="text-xs font-semibold text-red-400">HIGH PRIORITY</span>
              </div>
              <div className="flex flex-wrap gap-2">
                {['Weather', 'Traffic'].map((tag) => (
                  <span key={tag} className="px-3 py-1 rounded-full bg-pink-500/15 text-pink-300 text-xs font-medium border border-pink-500/20">
                    {tag}
                  </span>
                ))}
              </div>
              <div>
                <h4 className="text-white font-semibold text-sm mb-1">Summary</h4>
                <p className="text-gray-300 text-sm leading-relaxed">
                  Heavy rain has created a dangerous situation and is affecting road traffic.
                </p>
              </div>
              <div>
                <h4 className="text-white font-semibold text-sm mb-2">Recommended Actions</h4>
                <ol className="space-y-1.5">
                  {['Ensure immediate safety', 'Contact emergency services', 'Alert people nearby', 'Document the situation'].map((a, i) => (
                    <li key={i} className="flex items-start gap-2.5 text-sm text-gray-300">
                      <span className="flex-shrink-0 w-5 h-5 rounded-full bg-pink-500/20 text-pink-300 text-xs font-semibold flex items-center justify-center mt-0.5">
                        {i + 1}
                      </span>
                      {a}
                    </li>
                  ))}
                </ol>
              </div>
            </div>
          </div>
        </div>
      </div>
    ),
  },
  {
    id: 6,
    title: 'Technology',
    render: () => (
      <div className="flex flex-col justify-center h-full px-12 max-w-4xl mx-auto">
        <h2 className="text-5xl font-bold text-white mb-3">Technology Stack</h2>
        <div className="w-20 h-1 bg-pink-500 rounded-full mb-8" />
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {[
            { icon: Code2, title: 'React + TypeScript', desc: 'Type-safe, component-based frontend with Vite' },
            { icon: Sparkles, title: 'Tailwind CSS', desc: 'Utility-first styling with a custom dark theme' },
            { icon: Database, title: 'Supabase Database', desc: 'Postgres with Row Level Security for conversations and messages' },
            { icon: Cloud, title: 'Supabase Edge Functions', desc: 'Serverless AI analysis engine running on Deno' },
          ].map((tech, i) => {
            const Icon = tech.icon;
            return (
              <div
                key={i}
                className="flex items-start gap-4 p-6 rounded-2xl bg-[#1a1a24] border border-white/5 hover:border-pink-500/20 transition-colors"
              >
                <div className="flex-shrink-0 w-12 h-12 rounded-xl bg-gradient-to-br from-pink-500/20 to-pink-600/20 border border-pink-500/20 flex items-center justify-center">
                  <Icon className="w-6 h-6 text-pink-400" />
                </div>
                <div>
                  <h3 className="text-white font-semibold text-lg mb-1">{tech.title}</h3>
                  <p className="text-gray-400 text-sm leading-relaxed">{tech.desc}</p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    ),
  },
  {
    id: 7,
    title: 'Use Cases',
    render: () => (
      <div className="flex flex-col justify-center h-full px-12 max-w-4xl mx-auto">
        <h2 className="text-5xl font-bold text-white mb-3">Use Cases</h2>
        <div className="w-20 h-1 bg-pink-500 rounded-full mb-8" />
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {[
            { icon: CloudRain, title: 'Weather Emergencies', desc: 'Flooding, storms, and extreme weather situations' },
            { icon: Car, title: 'Traffic Incidents', desc: 'Accidents, road closures, and traffic hazards' },
            { icon: Zap, title: 'Utility Failures', desc: 'Power outages, water leaks, and infrastructure issues' },
            { icon: ShieldAlert, title: 'Community Safety', desc: 'Theft, security concerns, and neighborhood problems' },
          ].map((useCase, i) => {
            const Icon = useCase.icon;
            return (
              <div
                key={i}
                className="p-6 rounded-2xl bg-[#1a1a24] border border-white/5 hover:border-pink-500/20 transition-colors"
              >
                <div className="w-12 h-12 rounded-xl bg-pink-500/10 flex items-center justify-center mb-4">
                  <Icon className="w-6 h-6 text-pink-400" />
                </div>
                <h3 className="text-white font-semibold text-lg mb-2">{useCase.title}</h3>
                <p className="text-gray-400 text-sm leading-relaxed">{useCase.desc}</p>
              </div>
            );
          })}
        </div>
      </div>
    ),
  },
  {
    id: 8,
    title: 'Thank You',
    render: () => (
      <div className="flex flex-col items-center justify-center h-full text-center px-8">
        <div className="w-20 h-20 rounded-3xl bg-gradient-to-br from-pink-500 to-pink-600 flex items-center justify-center mb-8 shadow-2xl shadow-pink-500/30 animate-[float_3s_ease-in-out_infinite]">
          <Globe className="w-10 h-10 text-white" />
        </div>
        <h2 className="text-5xl font-bold text-white mb-4">
          Bridge<span className="text-pink-400">AI</span>
        </h2>
        <p className="text-xl text-gray-400 max-w-xl leading-relaxed mb-8">
          Turning human problems into clear and useful actions — one analysis at a time.
        </p>
        <div className="flex items-center gap-2 text-gray-600 text-sm">
          <Sparkles className="w-4 h-4 text-pink-400" />
          <span>Powered by Gemini AI</span>
        </div>
      </div>
    ),
  },
];

interface PresentationProps {
  onClose: () => void;
}

export default function Presentation({ onClose }: PresentationProps) {
  const [current, setCurrent] = useState(0);

  const next = useCallback(() => {
    setCurrent((prev) => Math.min(prev + 1, slides.length - 1));
  }, []);

  const prev = useCallback(() => {
    setCurrent((prev) => Math.max(prev - 1, 0));
  }, []);

  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'ArrowRight' || e.key === ' ') next();
      else if (e.key === 'ArrowLeft') prev();
      else if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [next, prev, onClose]);

  return (
    <div className="fixed inset-0 bg-[#0b0b12] z-50 flex flex-col">
      <div className="flex items-center justify-between px-6 py-4 border-b border-white/5">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-pink-500 to-pink-600 flex items-center justify-center">
            <Globe className="w-5 h-5 text-white" />
          </div>
          <span className="font-semibold text-white">BridgeAI Presentation</span>
        </div>
        <div className="flex items-center gap-4">
          <span className="text-gray-500 text-sm">
            {current + 1} / {slides.length}
          </span>
          <button
            onClick={onClose}
            className="p-2 rounded-lg hover:bg-white/5 transition-colors text-gray-400 hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>

      <div className="flex-1 relative overflow-hidden">
        <div
          className="absolute inset-0 transition-transform duration-500 ease-out"
          style={{ transform: `translateX(-${current * 100}%)` }}
        >
          <div className="flex h-full">
            {slides.map((slide) => (
              <div key={slide.id} className="w-full h-full flex-shrink-0">
                {slide.render()}
              </div>
            ))}
          </div>
        </div>

        <button
          onClick={prev}
          disabled={current === 0}
          className="absolute left-4 top-1/2 -translate-y-1/2 w-11 h-11 rounded-full bg-white/5 hover:bg-white/10 disabled:opacity-20 disabled:cursor-not-allowed transition-all flex items-center justify-center text-white"
        >
          <ChevronLeft className="w-6 h-6" />
        </button>
        <button
          onClick={next}
          disabled={current === slides.length - 1}
          className="absolute right-4 top-1/2 -translate-y-1/2 w-11 h-11 rounded-full bg-white/5 hover:bg-white/10 disabled:opacity-20 disabled:cursor-not-allowed transition-all flex items-center justify-center text-white"
        >
          <ChevronRight className="w-6 h-6" />
        </button>
      </div>

      <div className="px-6 py-4 border-t border-white/5">
        <div className="flex items-center justify-center gap-2">
          {slides.map((slide, i) => (
            <button
              key={slide.id}
              onClick={() => setCurrent(i)}
              className={`h-2 rounded-full transition-all duration-300 ${
                i === current
                  ? 'w-8 bg-pink-500'
                  : 'w-2 bg-white/20 hover:bg-white/30'
              }`}
              aria-label={slide.title}
            />
          ))}
        </div>
      </div>
    </div>
  );
}
