import { Globe, CloudRain, Car, Zap, ShieldAlert } from 'lucide-react';

interface WelcomeScreenProps {
  onExample: (text: string) => void;
}

const examples = [
  {
    icon: CloudRain,
    title: 'Flooding',
    text: 'Heavy rain has flooded the main road and cars are getting stuck. The water is rising fast and some drivers are trying to drive through it.',
  },
  {
    icon: Zap,
    title: 'Power Outage',
    text: 'A power line fell down near the park after a storm. Sparks are coming from it and kids play in that area every evening.',
  },
  {
    icon: Car,
    title: 'Traffic Accident',
    text: 'Two cars collided at the main intersection. One car is badly damaged and the driver seems hurt. Traffic is backing up quickly.',
  },
  {
    icon: ShieldAlert,
    title: 'Community Safety',
    text: 'There has been a series of thefts in our neighborhood over the past week. Several houses were broken into at night.',
  },
];

export default function WelcomeScreen({ onExample }: WelcomeScreenProps) {
  return (
    <div className="flex flex-col items-center justify-center h-full px-4 py-8">
      <div className="w-20 h-20 rounded-3xl bg-gradient-to-br from-pink-500 to-pink-600 flex items-center justify-center mb-6 shadow-xl shadow-pink-500/20">
        <Globe className="w-10 h-10 text-white" />
      </div>
      <h1 className="text-3xl font-bold text-white mb-2">
        BridgeAI
      </h1>
      <p className="text-gray-400 text-center max-w-md mb-10">
        Turning human problems into clear and useful actions with Gemini AI
      </p>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 w-full max-w-2xl">
        {examples.map((ex, i) => {
          const Icon = ex.icon;
          return (
            <button
              key={i}
              onClick={() => onExample(ex.text)}
              className="group flex items-start gap-3 p-4 rounded-xl bg-[#1a1a24] border border-white/5 hover:border-pink-500/30 hover:bg-[#1e1e2e] transition-all duration-200 text-left"
            >
              <div className="flex-shrink-0 w-10 h-10 rounded-lg bg-pink-500/10 flex items-center justify-center group-hover:bg-pink-500/20 transition-colors">
                <Icon className="w-5 h-5 text-pink-400" />
              </div>
              <div>
                <p className="text-white font-medium text-sm mb-1">{ex.title}</p>
                <p className="text-gray-500 text-xs leading-relaxed line-clamp-2">{ex.text}</p>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
}
