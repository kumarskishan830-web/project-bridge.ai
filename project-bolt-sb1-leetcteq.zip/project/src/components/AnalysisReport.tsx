import {
  AlertTriangle,
  AlertCircle,
  Info,
  Users,
  CheckCircle2,
  ShieldAlert,
  Tag,
} from 'lucide-react';
import { Analysis } from '@/types';

interface AnalysisReportProps {
  analysis: Analysis;
}

const priorityConfig = {
  high: {
    icon: AlertTriangle,
    color: 'text-red-400',
    bg: 'bg-red-500/10',
    border: 'border-red-500/30',
    label: 'HIGH PRIORITY',
  },
  medium: {
    icon: AlertCircle,
    color: 'text-amber-400',
    bg: 'bg-amber-500/10',
    border: 'border-amber-500/30',
    label: 'MEDIUM PRIORITY',
  },
  low: {
    icon: Info,
    color: 'text-sky-400',
    bg: 'bg-sky-500/10',
    border: 'border-sky-500/30',
    label: 'LOW PRIORITY',
  },
};

export default function AnalysisReport({ analysis }: AnalysisReportProps) {
  const config = priorityConfig[analysis.priorityLevel];
  const PriorityIcon = config.icon;

  return (
    <div className="space-y-5">
      <div className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-full ${config.bg} ${config.border} border`}>
        <PriorityIcon className={`w-4 h-4 ${config.color}`} />
        <span className={`text-xs font-semibold ${config.color}`}>{config.label}</span>
      </div>

      <div className="flex flex-wrap gap-2">
        {analysis.tags.map((tag, i) => (
          <span
            key={i}
            className="inline-flex items-center gap-1 px-3 py-1 rounded-full bg-pink-500/15 text-pink-300 text-xs font-medium border border-pink-500/20"
          >
            <Tag className="w-3 h-3" />
            {tag}
          </span>
        ))}
      </div>

      <div>
        <h4 className="text-white font-semibold text-sm mb-1.5">Summary</h4>
        <p className="text-gray-300 text-sm leading-relaxed">{analysis.summary}</p>
      </div>

      <div>
        <h4 className="text-white font-semibold text-sm mb-1.5 flex items-center gap-1.5">
          <Users className="w-4 h-4 text-pink-400" />
          People Affected
        </h4>
        <p className="text-gray-300 text-sm leading-relaxed">{analysis.affectedPeople}</p>
      </div>

      <div>
        <h4 className="text-white font-semibold text-sm mb-2 flex items-center gap-1.5">
          <CheckCircle2 className="w-4 h-4 text-green-400" />
          Recommended Actions
        </h4>
        <ol className="space-y-2">
          {analysis.actions.map((action, i) => (
            <li key={i} className="flex items-start gap-2.5 text-sm text-gray-300">
              <span className="flex-shrink-0 w-5 h-5 rounded-full bg-pink-500/20 text-pink-300 text-xs font-semibold flex items-center justify-center mt-0.5">
                {i + 1}
              </span>
              <span className="leading-relaxed">{action}</span>
            </li>
          ))}
        </ol>
      </div>

      <div className={`p-4 rounded-xl ${config.bg} ${config.border} border`}>
        <h4 className="text-white font-semibold text-sm mb-1.5 flex items-center gap-1.5">
          <ShieldAlert className={`w-4 h-4 ${config.color}`} />
          Safety Warning
        </h4>
        <p className="text-gray-300 text-sm leading-relaxed">{analysis.safetyWarning}</p>
      </div>
    </div>
  );
}
