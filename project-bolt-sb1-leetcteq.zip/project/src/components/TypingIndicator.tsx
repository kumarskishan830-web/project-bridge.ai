import { Sparkles } from 'lucide-react';

export default function TypingIndicator() {
  return (
    <div className="flex gap-3">
      <div className="flex-shrink-0 w-9 h-9 rounded-full flex items-center justify-center bg-gradient-to-br from-violet-500 to-purple-600">
        <Sparkles className="w-5 h-5 text-white" />
      </div>
      <div className="rounded-2xl px-5 py-4 bg-[#1e1e2e] border border-white/5">
        <div className="flex items-center gap-1.5">
          <span className="w-2 h-2 rounded-full bg-pink-400 animate-bounce" style={{ animationDelay: '0ms' }} />
          <span className="w-2 h-2 rounded-full bg-pink-400 animate-bounce" style={{ animationDelay: '150ms' }} />
          <span className="w-2 h-2 rounded-full bg-pink-400 animate-bounce" style={{ animationDelay: '300ms' }} />
          <span className="text-gray-400 text-sm ml-2">Analyzing your situation...</span>
        </div>
      </div>
    </div>
  );
}
